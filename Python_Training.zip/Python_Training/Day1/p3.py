pname = 'router'
vname = 'cisco'
code = 'r123'
cost = 1000.32  # cost = '1000.32Rs'
product_status = True
'''
print(pname)
print(vname)
print(code,cost,product_status)

print(f'Product name is:{pname}\nvendor name:{vname}\n{pname} code:{code}')
print(f'{pname} Cost is:{cost}\n{pname} working status:{product_status}')
'''
print(f'''Product name is:{pname}
---------------------------------
Vendor name:{vname}
----------------------
{pname} code number is:{code}
------------------------------
{pname} cost is:{cost}
-----------------------
{pname} working status is:{product_status}
-------------------------------------------''')
