print("Hello")
print("Data-1")
print('Data-2')
#print(10+20)
#print(Data3)
#single line comment
print(100+200) # simple arithmetic
'''
this is called multiline
comment
python supports int and floating point
arithmetic and relational operations
print(10+20.0)
print(150+233)
print(150>100)
'''
print('Another way')
"""
print("device1")
print("device2")
"""
print('End of the line')
