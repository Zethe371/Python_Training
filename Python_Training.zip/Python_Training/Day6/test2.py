import math
def test_funcblock1():
	n=25
	assert math.sqrt(n) == 5
def test_function2():
	n=5
	assert 5+5 == 10
def test_func3():
	n=15
	assert n <10