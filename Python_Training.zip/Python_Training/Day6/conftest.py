import pytest

@pytest.fixture
def f1():
	input=50
	return input