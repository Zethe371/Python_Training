import pytest

def test_f3(f1):
	assert f1 % 3 == 0
def test_f4(f1):
	assert f1 % 6 == 0
