import pytest

def test_f5(f1):
	assert f1 % 10 == 0